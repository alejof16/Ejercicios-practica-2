import os
import fileinput
from tkinter import E

def menuDisplay():
    print("Inventario de productos")
    print("=============================")
    print("1. agregar articulo al inventario")
    print("2. actualizar inventario")
    print("3. imprimir todo el inventario")
    print("4. salir")

    eleccion = int(input(" Selecciona la opcion: "))
    menuSelection(eleccion)

def menuSelection(eleccion):
    if eleccion == 1:
        addInventory()
    elif eleccion == 2:
        updateInventory()
    elif eleccion == 3:
        printInventory()
    elif eleccion == 4:
        exit()

def addInventory():
    archivoinventario = open('Inventario.txt', 'a')
    print("Agregando inventario nuevo")
    print("================")
    nombre_producto = input("ingese el nombre: ")
    cantidad_producto = input("ingrese la cantidad de el producto: ")
    archivoinventario.write(nombre_producto + '\n')
    archivoinventario.write(cantidad_producto + '\n')
    archivoinventario.close()
    eleccion = int(input('preciona 10 para salir  o 11 para volver al menu principal: '))
    if eleccion == 11:
            menuDisplay()
    else:
        exit()
    


def updateInventory():
    print("actualizar articulo:")
    print("==================")
    nombre_producto = input('ingrese el articulo a actualizar: ')
    producto_existencias = int(input("ingrese la nueva existencias"))

    with open('Inventario.txt', 'r') as f:
        filedata = f.readlines()

    replace = ""
    line_number = 0
    count = 0
    f = open('Inventario.txt','r')
    file = f.read().split('\n')
    for i, line in enumerate(file):
        if nombre_producto in line:
            for b in file[i+1:i+2]:
                value = int(b)
                change = value + (producto_existencias)
                replace = b.replace(b, str(change))
                line_number = count
            count = i + 1      
    f.close()
    
    filedata[count] = replace + '\n'

    with open('Inventario.txt', 'w') as f:
        for line in filedata:
            f.write(line)
                                            
                
    eleccion = int(input('preciona 10 para salir  o 11 para volver al menu principal: '))
    if eleccion == 11:
            menuDisplay()
    else:
        exit()


def printInventory():
    archivoinventario = open('Inventario.txt', 'r')
    nombre_producto = archivoinventario.readline()
    print('Actual inventario')
    print('-----------------')
    while nombre_producto != '':
        producto_existencias = archivoinventario.readline()
        nombre_producto = nombre_producto.rstrip('\n')
        producto_existencias = producto_existencias.rstrip('\n')
        
        print('nombre:     ', nombre_producto)
        print('existencia: ', producto_existencias)
        
        nombre_producto = archivoinventario.readline()
    archivoinventario.close()

    eleccion= int(input('preciona 10 para salir  o 11 para volver al menu principal: '))
    
    if eleccion  == 6:
            menuDisplay()
    else:
        exit()

menuDisplay()